
-- --------------------------------------------------------

--
-- Table structure for table `admit_bsc`
--

CREATE TABLE `admit_bsc` (
  `no` int(11) NOT NULL,
  `ssc_passing_year` int(200) NOT NULL,
  `ssc_roll` int(200) NOT NULL,
  `ssc_registration` int(200) NOT NULL,
  `ssc_board` varchar(200) NOT NULL,
  `hsc_passing_year` int(200) NOT NULL,
  `hsc_roll` int(200) NOT NULL,
  `hsc_registration` int(200) NOT NULL,
  `hsc_board` varchar(200) NOT NULL,
  `degree_name` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `institution_name` varchar(200) NOT NULL,
  `academic_board` varchar(200) NOT NULL,
  `grade` int(200) NOT NULL,
  `year` int(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `father_name` varchar(200) NOT NULL,
  `mother_name` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `marital_status` varchar(200) NOT NULL,
  `religion` varchar(200) NOT NULL,
  `nationality` varchar(200) NOT NULL,
  `phone` int(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admit_bsc`
--

INSERT INTO `admit_bsc` (`no`, `ssc_passing_year`, `ssc_roll`, `ssc_registration`, `ssc_board`, `hsc_passing_year`, `hsc_roll`, `hsc_registration`, `hsc_board`, `degree_name`, `description`, `institution_name`, `academic_board`, `grade`, `year`, `first_name`, `last_name`, `father_name`, `mother_name`, `gender`, `dob`, `marital_status`, `religion`, `nationality`, `phone`, `address`, `email`, `image`) VALUES
(10, 22, 2, 2, '2', 1, 1, 1, '1', '2', '2', '2', '2', 1, 1, '1', '1', '1', '1', 'male', '2023-06-30', 'single', '1', '1', 1, '1', '2@gda.com', 'maxresdefault.jpg'),
(11, 22, 2, 2, '2', 2, 22, 22, '22', '2', 'nk', '2', '2', 2, 2, '2', '2', '2', '2', 'male', '2023-06-16', 'single', '2', '2', 22, '2', '2@gda.com', 'accept.png');
