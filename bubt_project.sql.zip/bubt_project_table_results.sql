
-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `rno` int(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `intake` int(200) NOT NULL,
  `results` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`rno`, `department`, `semester`, `intake`, `results`) VALUES
(1, 'CSE', 'summer', 44, 'results.pdf'),
(2, 'CSE', 'summer', 45, 'results.pdf'),
(3, 'CSE', 'spring', 46, 'results.pdf'),
(4, 'BBA', 'summer', 50, 'results.pdf'),
(5, 'BBA', 'fall', 50, 'results.pdf'),
(6, 'EEE', 'summer', 20, 'results.pdf'),
(7, 'EEE', 'summer', 20, 'results.pdf'),
(8, 'Textile', 'spring', 22, 'results.pdf'),
(9, 'Textile', 'summer', 22, 'results.pdf');
