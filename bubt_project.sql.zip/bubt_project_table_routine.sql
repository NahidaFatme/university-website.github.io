
-- --------------------------------------------------------

--
-- Table structure for table `routine`
--

CREATE TABLE `routine` (
  `rno` int(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `intake` int(200) NOT NULL,
  `section` int(100) NOT NULL,
  `routine` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `routine`
--

INSERT INTO `routine` (`rno`, `department`, `intake`, `section`, `routine`) VALUES
(1, 'CSE', 44, 1, 'class_routine.pdf'),
(2, 'BBA', 50, 1, 'class_routine.pdf'),
(3, 'CSE', 44, 2, 'class_routine.pdf'),
(4, 'CSE', 44, 3, 'class_routine.pdf'),
(11, 'EEE', 20, 1, 'class_routine.pdf'),
(12, 'EEE', 20, 2, 'class_routine.pdf'),
(13, 'EEE', 20, 3, 'class_routine.pdf'),
(17, 'Textile', 22, 1, 'class_routine.pdf'),
(18, 'Textile', 22, 2, 'class_routine.pdf'),
(19, 'Textile', 22, 3, 'class_routine.pdf'),
(23, 'BBA', 50, 2, 'class_routine.pdf'),
(24, 'BBA', 50, 3, 'class_routine.pdf');
