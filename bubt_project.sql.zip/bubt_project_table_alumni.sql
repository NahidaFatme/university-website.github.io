
-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `ano` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`ano`, `name`, `designation`, `email`, `image`) VALUES
(1, 'Abu Hena Md. Sahin', 'President', 'demo@email.com', 'Abu_Hena_Md_Sahin.jpeg'),
(2, 'Nazmul Islam Bhuiya', 'Vice President', 'demo@email.com', 'Nazrul_Islam_Bhuiyan.jpeg'),
(3, 'Alim Al Razi', 'Vice President', 'demo@email.com', 'Alim_Al_Razi.jpg'),
(4, 'Mehedi Hasan Nahid', 'General Secretary', 'demo@email.com', 'Mehedi_Hasan_Nahid.jpeg'),
(5, 'Ali Sazzad Shohag', 'Joint Secretary', 'demo@email.com', 'no-profile.jpg'),
(6, 'Md. Faiz Ahmed', 'Joint Organization Secretary', 'demo@email.com', 'Md._Faiz_Ahamed_Shipu.jpeg'),
(7, 'Md Ashraful Islam', 'Research Secretary', 'demo@email.com', 'Md_Ashraful_Islam.jpg'),
(8, 'Taposhi Rabea', 'Publication & Media Secretary', 'demo@email.com', 'Taposhi_Rabea.jpeg'),
(9, 'Foysal Zafree', 'Cultural Secretary', 'demo@email.com', 'Foysal_Zafree.jpeg'),
(10, 'Sabbir Ahmed Saikat', 'General Member', 'demo@email.com', 'Sabbir_Ahmed_Saikat.jpeg'),
(11, 'Kaniz Fatema Mow', 'General Member', 'demo@email.com', 'Kaniz_Fatema_Mow.jpg'),
(12, 'Abu Rayhan Ahmed', 'General Member', 'demo@email.com', 'Abu_Rayhan_Ahmad.jpeg');
